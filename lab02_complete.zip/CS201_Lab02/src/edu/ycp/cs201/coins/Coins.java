package edu.ycp.cs201.coins;

public class Coins {
	// TODO: add fields here
	public int pennies, nickles, dimes, quarters;
	
	// TODO: add constructors
	public Coins(){
		pennies=0;
		nickles=0;
		dimes=0;
		quarters=0;
	}
	
	public Coins(int one, int five, int ten, int twofive){
		pennies=one;
		nickles=five;
		dimes=ten;
		quarters=twofive;
	}
	
	// TODO: add methods
	
	public int findCentsValue(){
		int sum=0;
		sum += pennies*1;
		sum += nickles*5;
		sum += dimes*10;
		sum += quarters*25;
		return sum;
	}
	
	public int findDollars(){
		int dollars = findCentsValue()/100;
		return dollars;
	}

	public int findChange(){
		int change = findCentsValue()%100;
		return change;
	}
}
