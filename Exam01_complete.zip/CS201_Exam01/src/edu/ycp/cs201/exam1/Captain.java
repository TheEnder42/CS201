package edu.ycp.cs201.exam1;

/**
 * An instance of the Captain class represents
 * a Star Fleet captain
 */
public class Captain {
	// TODO: add fields.
	// You need to store information about the Captain (use the following variable names and types:
	//     firstName (String), lastName (String), gradYear (int), shipName (String)
	private String firstName, lastName, shipName;
	private int gradYear;


	// TODO: add constructor that accepts first name and last name
	//       initialize gradYear to 0, and shipName to null
	public Captain(String first, String last){
		firstName = new String(first);
		lastName = new String(last);
		shipName = null;
		gradYear = 0;
	}


	// TODO: add constructor that accepts first name, last name, grad year, and ship name
	public Captain(String first, String last, int year, String ship){
		firstName = new String(first);
		lastName = new String(last);
		shipName = new String(ship);
		gradYear = year;
	}


	
	// TODO: add getter methods for each field in the Captain class
	//       the method names must MATCH those called in the JUNit test cases
	public int getGradYear() {
		return gradYear;
	}
	
	public String getShipName() {
		return shipName;
	}
	
	public String getLastName() {
		return lastName;
	}
	
	public String getFirstName() {
		return firstName;
	}


	// TODO: add setter methods for shipName and gradYear
	//       the method names MUST match those called in the JUnit test cases
	public void setGradYear(int year) {
		gradYear = year;
	}
	
	public void setShipName(String ship) {
		shipName = new String(ship);
	}

	
	// TODO: add a method that returns the Captain's full name in the form
	//                     "firstName lastName"
	//       the method name MUST match that called in the JUnit test case
	public String getFullName(){
		return firstName + " " + lastName;
	}
}
