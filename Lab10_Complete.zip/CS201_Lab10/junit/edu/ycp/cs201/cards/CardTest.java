package edu.ycp.cs201.cards;

import java.util.Arrays;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class CardTest {
	// TODO - define test fixture objects
	private Card sixOfClubs;
	private Card sixOfHearts;
	private Card fiveOfHearts;
	private Card kingOfDiamonds;
	private Card jackOfSpades;
	private Card[] hand = new Card[5];
	private Deck pack = new Deck();
	private Deck control = new Deck();
	private Card lowest;
	
	@Before
	public void setUp() throws Exception {
		// TODO - create test fixture objects
		sixOfClubs = new Card(Rank.SIX, Suit.CLUBS);
		sixOfHearts = new Card(Rank.SIX, Suit.HEARTS);
		fiveOfHearts = new Card(Rank.FIVE, Suit.HEARTS);
		kingOfDiamonds = new Card(Rank.KING, Suit.DIAMONDS);
		jackOfSpades = new Card(Rank.JACK, Suit.SPADES);
		lowest = new Card(Rank.TWO, Suit.CLUBS);

		
		hand[0]= kingOfDiamonds;
		hand[1]= fiveOfHearts;
		hand[2]= jackOfSpades;
		hand[3]= sixOfHearts;
		hand[4]= sixOfClubs;
	}
	
	public void sortCards(){
		Arrays.sort(hand);
	}
	
	public int mix(){
		pack.shuffle();
		int pos=0;
		for(int i=0; i<pack.getNumCards()-1; i++){
			if(pack.getCard(i).compareTo(control.getCard(i))!=0){
				pos++;
			}
		}
		return pos;
	}
	
	// TODO - add test methods
	
	@Test
	public void testGetSuit() {
		// TODO: test calling getSuit() on your Card objects 
		assertEquals(Suit.CLUBS, sixOfClubs.getSuit());
		assertEquals(Suit.HEARTS, fiveOfHearts.getSuit());
		assertEquals(Suit.DIAMONDS, kingOfDiamonds.getSuit());
		assertEquals(Suit.SPADES, jackOfSpades.getSuit());
	}
	
	@Test
	public void testGetRank() {
		// TODO: test calling getSuit() on your Card objects 
		assertEquals(Rank.SIX, sixOfClubs.getRank());
		assertEquals(Rank.FIVE, fiveOfHearts.getRank());
		assertEquals(Rank.KING, kingOfDiamonds.getRank());
		assertEquals(Rank.JACK, jackOfSpades.getRank());
	}
	
	@Test
	public void testCompareTo() {
		assertTrue(jackOfSpades.compareTo(kingOfDiamonds) > 0);
		assertTrue(sixOfClubs.compareTo(kingOfDiamonds) < 0);
		assertTrue(sixOfHearts.compareTo(fiveOfHearts) > 0);
		assertTrue(sixOfHearts.compareTo(sixOfClubs) > 0);
	}
	
	@Test
	public void testSortCards() {
		Arrays.sort(hand);
		for(int i=0; i<hand.length-1; i++){
			assertTrue(hand[i].compareTo(hand[i+1]) < 0);
		}
	}
	
	@Test
	public void testDeck() {
		assertEquals(lowest, pack.drawCard());
		assertEquals(kingOfDiamonds, pack.getCard(24));
		assertEquals(52, pack.getNumCards());
		assertTrue(mix() > 40);
	}
	
}
