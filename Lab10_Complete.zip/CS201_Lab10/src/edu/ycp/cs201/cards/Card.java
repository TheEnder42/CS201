package edu.ycp.cs201.cards;

public class Card implements Comparable<Card>{
	// TODO - add fields an methods
	private Suit mySuit;
	private Rank myRank;
	
	public Card(Rank r, Suit s) {
		myRank = r;
		mySuit = s;
	}
	
	public Rank getRank(){
		return myRank;
	}
	
	public Suit getSuit(){
		return mySuit;
	}

	@Override
	public int compareTo(Card c) {
		//Card c = new Card;
	
		int cmp;
		
		// compare suits, if they are different, use the difference
		// as the result of the comparison
		cmp = this.mySuit.compareTo(c.mySuit);
		if (cmp != 0) {
			return cmp;
		}
		
		// suits are the same, use the ranks as a tie-breaker
		cmp = this.myRank.compareTo(c.myRank);
		if (cmp != 0) {
			return cmp;
		}
		return cmp;
	}
	
	public boolean equals(Object obj){
		if (obj == null || !(obj instanceof Card)) {
			return false;
		}
		Card other = (Card) obj;
		return this.myRank == other.myRank && this.mySuit == other.mySuit;
	}
		
}
