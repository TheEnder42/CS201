package edu.ycp.cs201.cards;

import java.util.ArrayList;
import java.util.Collections;

public class Deck {
    private ArrayList<Card> deck = new ArrayList<Card>();

    public Deck() {
        // generate a full deck (52 cards)
    	Suit[] allSuits = Suit.values();
    	Rank[] allRanks = Rank.values();
    	Card c;

    	for (int j = 0; j < allSuits.length; j++) {
    	    for (int i = 0; i < allRanks.length; i++) {
    	        // use allSuits[j] and allRanks[i] to create a Card
    	    	c = new Card(allRanks[i], allSuits[j]);
    	    	deck.add(c);
    	    }
    	}
    }

    public int getNumCards() {
        return deck.size();
    }

    public Card getCard(int i) {
        return deck.get(i);
    }

    public Card drawCard() {
        return deck.get(0);
    }

    public void shuffle() {
        // randomly shuffle the deck
        // use the Collections.shuffle() static method!
    	Collections.shuffle(deck);
    }
}