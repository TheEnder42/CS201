package edu.ycp.cs201.disks;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.Random;

import javax.swing.JPanel;
import javax.swing.Timer;

public class DisksPanel extends JPanel {
	private static final long serialVersionUID = 1L;

	public static final int WIDTH = 400;
	public static final int HEIGHT = 300;
	public static final int TICKS = 50;
	
	private Timer timer;
	// TODO: add any other fields you need to represent the state of the game
	private int mouseX, mouseY, radius, disks, ticksLeft;
	private Disk[] placedDisks;
	private Random myNum = new Random();
	private boolean gameOver=false;
	
	public DisksPanel() {
		setPreferredSize(new Dimension(WIDTH, HEIGHT));
		setBackground(Color.GRAY);
		
		addMouseListener(new MouseAdapter(){
			@Override
			public void mouseClicked(MouseEvent e) {
				handleMouseClick(e);
			}
		});
		
		addMouseMotionListener(new MouseAdapter() {
			@Override
			public void mouseMoved(MouseEvent e) {
				handleMouseMove(e);
			}
		});
		
		// Schedule timer events to fire every 100 milliseconds (0.1 seconds)
		this.timer = new Timer(100, new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				handleTimerEvent(e);
			}
		});
		
		placedDisks = new Disk[200];
		radius=randomInt(34);
		disks=0;
		//myNum ;
		ticksLeft=TICKS;
	}

	// You can call this method to convert a DiskColor value into
	// a java.awt.Color object.
	public Color colorOf(DiskColor dc) {
		return new Color(dc.red(), dc.green(), dc.blue());
	}

	// This method is called whenever the mouse is moved
	protected void handleMouseMove(MouseEvent e) {
		// TODO
		mouseX = e.getX();
		mouseY = e.getY();
		//drag outline
		repaint();
	}
	
	// This method is called whenever the mouse is clicked
	protected void handleMouseClick(MouseEvent e) {
		// TODO
		if(!gameOver){
		DiskColor newDiskColor = DiskColor.values()[randomInt(4)];
		Disk temp = new Disk(e.getX(), e.getY(), radius, newDiskColor);
		if(temp.isOutOfBounds(WIDTH, HEIGHT)){
			gameOver=true;
			timer.stop();
		}
		for(int i=0; i<disks; i++){
			if(disks>0){
				if(temp.overlaps(placedDisks[i])){
					gameOver=true;
					timer.stop();
				}
			}
		}
		timer.stop();
		placedDisks[disks]=temp;
		disks++;
		radius = randomInt(34);
		ticksLeft=TICKS-(disks*3);
		
		repaint();
		
			timer.start();
		}
		
	}
	
	// This method is called whenever a timer event fires
	protected void handleTimerEvent(ActionEvent e) {
		// TODO
		ticksLeft--;
		if(ticksLeft==0){
			gameOver=true;
			timer.stop();
		}
		repaint();
	}
	
	private static final Font FONT = new Font("Dialog", Font.BOLD, 24);

	// This method is called automatically whenever the contents of
	// the window need to be redrawned.
	@Override
	public void paintComponent(Graphics g) {
		// Paint the window background
		super.paintComponent(g);
		
		// TODO: draw everything that needs to be drawn
		
		for(int i=0; i<disks; i++){
			DiskColor newDiskColor = DiskColor.values()[i];
			g.setColor(new Color(placedDisks[i].getColor().green()));
			//g.setColor(placedDisks[i].getColor().blue());
			g.fillOval((int)placedDisks[i].getX()-radius, (int)placedDisks[i].getY()-radius, (int)placedDisks[i].getRadius()*2, (int)placedDisks[i].getRadius()*2);
		}
		Color barColor = new Color(255, 23, 23, 63);
		g.setColor(barColor);
		g.fillRect(0, HEIGHT-45, WIDTH-(WIDTH-(ticksLeft*8)), 25);
		
		g.setFont(FONT);
		g.setColor(Color.black);
		g.drawString(""+disks, 10, 20);
		if(gameOver){
			g.drawString("GAME OVER!", WIDTH/2-90, HEIGHT/2);
		}
		g.setColor(Color.black);
		g.drawOval(mouseX-radius, mouseY-radius, radius*2, radius*2);
	}
	
	public int randomInt(int n){
		int temp=0;
		temp = myNum.nextInt(n)+10;
		//System.out.println(temp);
		//return 12;
		return temp;
	}//end make random
	
}
