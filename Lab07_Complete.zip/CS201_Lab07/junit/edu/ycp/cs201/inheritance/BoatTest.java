package edu.ycp.cs201.inheritance;

import junit.framework.TestCase;

public class BoatTest extends TestCase {
	private Trip legalTrip;
	private Trip illegalTrip;
	private Boat myBoat;
	
	@Override
	protected void setUp() throws Exception {
		// a Trip that can be completed by Boat
		legalTrip = new Trip(4);
		legalTrip.setHop(0, Terrain.MARINA);
		legalTrip.setHop(1, Terrain.WATER);
		legalTrip.setHop(2, Terrain.WATER);
		legalTrip.setHop(3, Terrain.MARINA);
		
		// a Trip that cannot be completed by Boat
		// because it contains a hop through land
		illegalTrip = new Trip(5);
		illegalTrip.setHop(0, Terrain.MARINA);
		illegalTrip.setHop(1, Terrain.ROAD);  // Not possible by Boat!
		illegalTrip.setHop(2, Terrain.ROAD);  // Not possible by Boat!
		illegalTrip.setHop(3, Terrain.WATER); 
		illegalTrip.setHop(4, Terrain.MARINA);
		
		myBoat = new Boat();
	}
	
	public void testLegalTrip() throws Exception {
		assertTrue(legalTrip.isTripPossible(myBoat));
	}
	
	public void testIllegalTrip() throws Exception {
		assertFalse(illegalTrip.isTripPossible(myBoat));
	}
}
