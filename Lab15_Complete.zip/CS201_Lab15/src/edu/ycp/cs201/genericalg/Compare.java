package edu.ycp.cs201.genericalg;

import java.util.Comparator;

public class Compare<E extends Comparable<E>> implements Comparator<E>{

	@Override
	public int compare(E left, E right) {
		return left.compareTo(right);
	}
	
	

}
