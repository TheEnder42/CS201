package edu.ycp.cs201.genericalg;

import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;

public class Algorithms {
	public static<E extends Comparable<E>> E findMin(Collection<E> c) {
		/*E temp;
		Iterator<E> k = c.iterator();
		temp = k.next();
		E val;
		while (k.hasNext()) {
			val = k.next();
			if(temp.compareTo(val)>0){
				temp = val;
			}
		}
		return temp;*/
		Compare<E> comp = new Compare<E>();
		return findMin(c, comp);
	}
	
	public static<E> E findMin(Collection<E> c, Comparator<E> comp) {
		E temp;
		Iterator<E> k = c.iterator();
		temp = k.next();
		E val;
		while (k.hasNext()) {
			val = k.next();
			if(comp.compare(temp, val)>0){
				temp = val;
			}
		}
		return temp;
	}

	public static<E extends Comparable<E>> E findMax(Collection<E> c) {
		/*E temp;
		Iterator<E> k = c.iterator();
		temp = k.next();
		E val;
		while (k.hasNext()) {
			val = k.next();
			if(temp.compareTo(val)<0){
				temp = val;
			}
		}
		return temp;*/
		ReverseCompare<E> comp = new ReverseCompare<E>();
		return findMin(c, comp);
	}
	
	public static<E> E findMax(Collection<E> c, final Comparator<E> comp) {
		/*E temp;
		Iterator<E> k = c.iterator();
		temp = k.next();
		E val;
		while (k.hasNext()) {
			val = k.next();
			if(comp.compare(temp, val)<0){
				temp = val;
			}
		}
		return temp;*/
		//ReverseCompare<E> rcomp = new ReverseCompare<E>();
//		Comparator<E> rcomp = new Comparator<E>() {
//			@Override
//			public int compare(E o1, E o2) {
//				return comp.compare(o2, o1);
//			}
//		};
		Comparator<E> rcomp = Collections.reverseOrder(comp);
		return findMin(c, rcomp);
	}
	
	public static<E> int sequentialSearch(List<E> list, E searchVal) {
		for(int i=0; i<list.size(); i++) {
			if(list.get(i)==searchVal){
				return i;
			}
		}
		return -1;
	}
}
