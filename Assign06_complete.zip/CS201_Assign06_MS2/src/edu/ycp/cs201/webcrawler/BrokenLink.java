package edu.ycp.cs201.webcrawler;

/**
 * This class represents a broken link.
 */
public class BrokenLink implements Comparable<BrokenLink> {
	private final URL pageURL;
	private final String link;
	
	/**
	 * Constructor.
	 * 
	 * @param pageURL the {@link URL} of the page on which the broken link occurred
	 * @param link the text of the broken link
	 */
	public BrokenLink(URL pageURL, String link) {
		this.pageURL = pageURL;
		this.link = link;
	}
	
	/**
	 * @return the {@link URL} of the page on which the broken link occurred
	 */
	public URL getPageURL() {
		return pageURL;
	}
	
	/**
	 * @return the text of the broken link
	 */
	public String getLink() {
		return link;
	}
	
	@Override
	public boolean equals(Object obj) {
		if (obj == null || !(obj instanceof BrokenLink)) {
			return false;
		}
		BrokenLink other = (BrokenLink) obj;
		return this.pageURL.equals(other.pageURL)
				&& this.link.equals(other.link);
	}
	
	@Override
	public int hashCode() {
		return pageURL.hashCode() * 1051 + link.hashCode();
	}
	
	@Override
	public int compareTo(BrokenLink o) {
		int cmp = this.pageURL.compareTo(o.pageURL);
		if (cmp != 0) {
			return cmp;
		}
		return this.link.compareTo(o.link);
	}
	
	@Override
	public String toString() {
		return link + ", referenced from " + pageURL;
	}
}
