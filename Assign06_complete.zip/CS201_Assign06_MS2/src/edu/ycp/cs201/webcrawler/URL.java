package edu.ycp.cs201.webcrawler;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.Stack;

/**
 * Class to represent a URL (an identifier which specifies
 * the location of a web resource.)
 */
public class URL implements Comparable<URL> {
	// TODO: add fields
	private String rep;
	
	/**
	 * Constructor.
	 * 
	 * @param s the text form of a URL
	 */
	public URL(String s) {
		rep = s;
		if ((getProtocol().equals("http:") || getProtocol().equals("https:")) && getHost().equals("")) {
			throw new IllegalArgumentException();
		}
	}
	
	/**
	 * Copy constructor.
	 * 
	 * @param other another {@link URL}: the object being initialized
	 *              should be made identical to this object
	 */
	public URL(URL other) {
		this.rep = other.rep;
	}
	
	/**
	 * @return true if this {@link URL} is absolute, false otherwise
	 */
	public boolean isAbsolute() {
		return getPath().startsWith("/");
//		if(rep.charAt(0)=='/'){
//			return true;
//		}
//		return false;
	}
	
	/**
	 * @return true if this {@link URL} names a directory, false otherwise
	 */
	public boolean isDirectory() {
		if(rep.charAt(rep.length()-1)=='/'){
			return true;
		}
		return false;
	}
	
	/**
	 * @return the protocol of this {@link URL}, e.g., "http:" for an HTTP URL;
	 *         returns an empty string if the URL doesn't specify a protocol
	 */
	public String getProtocol() {
		String result = "";
		//if(!isAbsolute()){
			result = rep.substring(0, rep.indexOf(':')+1);
		//}
		return result;
	}
	
	/**
	 * @return the hostname of this {@link URL}, e.g., "ycpcs.github.io";
	 *         returns an empty string if the URL doesn't specify a hostname
	 */
	public String getHost() {
		String result = "";
		String temp = "";
		int prolen=getProtocol().length();
		int slashslash = rep.indexOf('/');
		/*if(isAbsolute()){
			temp = rep.substring(2);
			result = rep.substring(0, temp.indexOf('/')+2);
		}
		else if(prolen==0 && rep.indexOf('.')>=0 && rep.indexOf('/')>=0 && rep.indexOf('/')<rep.indexOf('.')){
			//if it gets here, there is only the path
		}
		else{
			temp = rep.substring(prolen);
			//at this point, temp is the absolute URL
			temp = temp.substring(2);
			result = rep.substring(prolen, temp.indexOf('/')+2+prolen);
		}*/
		if(slashslash>=0 && rep.charAt(slashslash+1)=='/'){
			temp = rep.substring(slashslash+2);
			result = /* "//" + */rep.substring(prolen+2, temp.indexOf('/')+2+prolen);
		}
		return result;
	}
	
	/**
	 * Get the path part of the {@link URL}.
	 * If the URL is absolute, the path should start with "/".
	 * If the URL is a directory, the path should end with "/".
	 * 
	 * @return the path part of the URL
	 */
	public String getPath() {
		String result = "";
		int x = 0;
		if(getHost().length()>0){
			x = 2;
		}
		result = rep.substring(getProtocol().length()+getHost().length()+x);
		return result;
	}
	
	/**
	 * Get the directory part of this {@link URL}'s path, which is
	 * the text up to and including the last slash ("/")
	 * character in the path.  As a special case, if the
	 * path has no slash characters, return the empty string.
	 * 
	 * @return the directory part of this URL's path
	 */
	public String getDirectoryPart() {
		String result = "";
		String temp = getPath();
		if(temp.indexOf('/')==-1){
			return "";
		}
		else{
			while(temp.indexOf('/')!=-1){
				result += temp.substring(0, temp.indexOf('/')+1);
				temp = temp.substring(temp.indexOf('/')+1);
			}
		}
		return result;
	}
	
	/**
	 * @return true if the {@link URL}'s path is in canonical form, meaning
	 *         that there are no occurrences of "." or ".."; returns false
	 *         if the URL is not in canonical form
	 */
	public boolean isCanonical() {
		String path = getPath();
		String[] components = path.split("/");
		for(int i=0; i<components.length; i++){
			if(components[i].equals(".") || components[i].equals("..")){
				return false;
			}
		}
		return true;
	}

	/**
	 * Return a {@link URL} that is the canonical form of this URL.
	 * If the URL is already in canonical form, returns it unchanged.
	 * 
	 * @throws IllegalArgumentException if the URL cannot be made
	 *         canonical because it references path components "below"
	 *         the implicit starting point of the URL: e.g., the
	 *         URL "foo/../../bar.html" cannot be made canonical
	 */
	public URL makeCanonical() throws IllegalArgumentException {
		String result = "";
		String path = getPath();
		if(!isCanonical()){
			String[] components = path.split("/");
			Stack<String> partStack = new Stack<String>();
			//check can make canonical each iteration
			//sorting
			for(int i=0; i<components.length; i++){
				if(components[i].equals(".")){
					//do nothing
				}
				else if(components[i].equals("..")){
					if(partStack.empty()){
						throw new IllegalArgumentException("I transcended the origin.");
					}
					else{
						partStack.pop();
					}
				}
				else{
					partStack.push(components[i]);
				}
			}
			//System.out.println("partStack=" + partStack);
			//rebuilding, needs checks
			String slash = "";
			//for(int i=0; i<partStack.size(); i++){
			while (!partStack.isEmpty()) {
				//if empty, don't have slash, checks
				if(result != ""){
					slash = "/";
				}
				result = partStack.pop() + slash + result;
			}
		}
		else{
			result = path;
		}
		String host =  getHost();
		if(host.length()!=0){
			host = "//" + host;
		}
		URL URLresult = new URL(getProtocol() + host + result);
		
		return URLresult;
	}

	/**
	 * Return the absolute canonical form of a referenced URL.
	 * 
	 * <p>If the referenced URL has no protocol, and is absolute,
	 * return the canonical form of the URL that has the same
	 * protocol and host as this one, but the other
	 * URL's path.
	 * 
	 * <p>If the referenced URL has no protocol, and is relative,
	 * return the canonical form of the URL that has the same
	 * protocol and host as this one, but whose path is the
	 * result of appending the other URL's path to the directory
	 * part of this URL's path.
	 * 
	 * <p>If the referenced URL has a protocol, return its canonical
	 * form.
	 *  
	 * @param refURL a referenced {@link URL}
	 * @return the canonical form of the referenced 
	 * 
	 * @throws IllegalArgumentException if the referenced URL cannot
	 *         be made absolute and canonical
	 */
	public URL getReferencedURL(URL refURL) throws IllegalArgumentException{
		URL URLresult;
		String host =  getHost();
		if(host.length()!=0){
			host = "//" + host;
		}
		if(refURL.isAbsolute() && refURL.getProtocol().length()==0){
			URLresult = new URL(getProtocol() + host + refURL.getPath());
		}
		else if(refURL.getProtocol().length()==0 && !refURL.isAbsolute()){
			URLresult = new URL(getProtocol() + host + getDirectoryPart() + refURL.getPath());
			URLresult = URLresult.makeCanonical();
		}
		else if(refURL.getProtocol().length()>0){
			URLresult = refURL.makeCanonical();
		}
		else{
			URLresult = new URL("you messed up");
		}
		return URLresult;
	}
	
	@Override
	public boolean equals(Object obj) {
		// Note: you will not need to modify this method
		if (obj == null || !(obj instanceof URL)) {
			return false;
		}
		return this.toString().equals(obj.toString());
	}
	
	@Override
	public int hashCode() {
		// Note: you will not need to modify this method
		return toString().hashCode();
	}
	
	@Override
	public int compareTo(URL o) {
		// Note: you will not need to modify this method
		return this.toString().compareTo(o.toString());
	}
	
	@Override
	public String toString() {
		return rep;
	}
	
	// TODO: you can add helper methods if you would like to
}
