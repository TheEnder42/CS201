package edu.ycp.cs201.webcrawler;

import java.util.HashSet;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * A {@link Crawler} object is given a start {@link URL} (i.e., the URL
 * of a starting web page), scans it for links, and then visits all
 * of the linked-to web pages, until no new web pages can be discovered.
 * It keeps track of:
 * <ol>
 * <li>Visited pages</li>
 * <li>Broken links</li>
 * <li>Links to web pages which are outside the website of the starting URL,
 *     or are not text resources (i.e., PDFs, zip files, image files, etc.)</li>
 * </ol>
 */
public class Crawler {
	private URL startURL;
	// TODO: add additional fields
	Set<URL> visited;
	Set<BrokenLink> brokenLinks;
	Set<URL> outside_non;
	
	/**
	 * Constructor.
	 * 
	 * @param startURL {@link URL} of the web page where the crawl should start
	 */
	public Crawler(URL startURL) {
		if (!startURL.isAbsolute() || !startURL.isCanonical()) {
			throw new IllegalArgumentException("Start URL must be absolute and canonical");
		}
		this.startURL = startURL;
		// TODO: initial other fields
		visited = new HashSet<URL>();
		brokenLinks = new HashSet<BrokenLink>();
		outside_non = new HashSet<URL>();
	}
	
	private static final Pattern NAKED_SITE_URL_PAT =
			Pattern.compile("^https?://[A-Za-z0-9.\\-]+(:\\d+)?");
	
	/**
	 * Crawl the start page and all webpages on the same website
	 * that are reachable, keeping track of visited pages, broken links,
	 * and links to web pages outside of the website of the starting page.
	 */
	public void crawl() {
		Fetcher fetcher = new Fetcher(this.startURL);
		
		Queue<URL> q = new LinkedList<URL>();
		q.add(startURL);
		
		while (!q.isEmpty()) {
			// Get the URL of the next page to visit
			URL pageURL = q.remove();
			
			// Make sure we haven't already visited this page
			if (alreadyVisited(pageURL)) {
				continue;
			}
			
			// Mark this page as visited
			markVisited(pageURL);
			
			// This page is part of the site we're crawling:
			// extract its links and consider adding them to the queue
			Set<String> links = LinkExtractor.extractLinks(pageURL, fetcher);
			if (links == null) {
				throw new IllegalStateException("Can't load page " + pageURL);
			}
			for (String link : links) {
				
				// Special case: if the URL is of the form
				//     http://some.site.com
				// append a slash to honor the conventions of our URL class
				// (which assumes that all http/https URLs have a path.
				Matcher m = NAKED_SITE_URL_PAT.matcher(link);
				if (m.matches()) {
					link += "/";
				}
				
				// Convert the link to canonical form
				//System.out.printf("[%s]link=%s\n", pageURL.toString(), link);
				URL refURL = pageURL.getReferencedURL(new URL(link));
				
				// See if the linked resource is a web page belonging
				// to the same website.
				if (fetcher.allowFetch(refURL)) {
					// See whether it exists
					if (!fetcher.exists(refURL)) {
						recordBrokenLink(new BrokenLink(pageURL, link));
					} else if (!alreadyVisited(refURL)) {
						q.add(refURL);
					}
				}
			}
		}
	}
	
	/**
	 * Determine whether specified page has already been visited.
	 * 
	 * @param pageURL the URL of a web page
	 * @return true if the page has been visited, false otherwise
	 */
	protected boolean alreadyVisited(URL pageURL) {
		if(visited.contains(pageURL)){
			return true;
		}
		return false;
	}
	
	/**
	 * Mark the specified page as having been visited.
	 * This is important, since we don't want to visit any web page
	 * more than once.
	 * 
	 * @param pageURL the URL of a web page
	 */
	protected void markVisited(URL pageURL) {
		visited.add(pageURL);
	}
	
	/**
	 * Record a broken link.
	 * 
	 * @param brokenLink a {@link BrokenLink} object representing the broken link
	 */
	protected void recordBrokenLink(BrokenLink brokenLink) {
		brokenLinks.add(brokenLink);
	}
	
	/**
	 * Get the set of {@link URL}s of visited web pages.
	 * Should only be called after {@link #crawl()} has finished.
	 * 
	 * @return set of {@link URL}s of visited web pages
	 */
	public Set<URL> getVisited() {
		return visited;
	}
	
	/**
	 * Get the set of broken links.
	 * Should only be called after {@link #crawl()} has finished.
	 * 
	 * @return set of broken links
	 */
	public Set<BrokenLink> getBroken() {
		return brokenLinks;
	}
	
	public static void main(String[] args) {
		Scanner keyboard = new Scanner(System.in);
		System.out.print("Enter start URL: ");
		String line = keyboard.nextLine();
		
		URL startURL = new URL(line);
		Crawler crawler = new Crawler(startURL) {
			@Override
			public void markVisited(URL pageURL) {
				super.markVisited(pageURL);
				System.out.print(".");
				System.out.flush();
			}
		};
		crawler.crawl();
		System.out.println();
		
		System.out.println("Visited links:");
		for (URL u : crawler.getVisited()) {
			System.out.println("  " + u);
		}
		System.out.println("Broken links:");
		for (BrokenLink b : crawler.getBroken()) {
			System.out.println("  " + b);
		}
	}
}
