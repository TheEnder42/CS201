package edu.ycp.cs201.cards;

import java.util.Arrays;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class CardTest {
	// TODO - define test fixture objects
	private Card sixOfClubs;
	private Card sixOfHearts;
	private Card fiveOfHearts;
	private Card kingOfDiamonds;
	private Card jackOfSpades;
	private Card[] deck = new Card[5];
	
	@Before
	public void setUp() throws Exception {
		// TODO - create test fixture objects
		sixOfClubs = new Card(Rank.SIX, Suit.CLUBS);
		sixOfHearts = new Card(Rank.SIX, Suit.HEARTS);
		fiveOfHearts = new Card(Rank.FIVE, Suit.HEARTS);
		kingOfDiamonds = new Card(Rank.KING, Suit.DIAMONDS);
		jackOfSpades = new Card(Rank.JACK, Suit.SPADES);
		
		deck[0]= kingOfDiamonds;
		deck[1]= fiveOfHearts;
		deck[2]= jackOfSpades;
		deck[3]= sixOfHearts;
		deck[4]= sixOfClubs;
	}
	
	public void sortCards(){
		Arrays.sort(deck);
	}
	
	// TODO - add test methods
	
	@Test
	public void testGetSuit() {
		// TODO: test calling getSuit() on your Card objects 
		assertEquals(Suit.CLUBS, sixOfClubs.getSuit());
		assertEquals(Suit.HEARTS, fiveOfHearts.getSuit());
		assertEquals(Suit.DIAMONDS, kingOfDiamonds.getSuit());
		assertEquals(Suit.SPADES, jackOfSpades.getSuit());
	}
	
	@Test
	public void testGetRank() {
		// TODO: test calling getSuit() on your Card objects 
		assertEquals(Rank.SIX, sixOfClubs.getRank());
		assertEquals(Rank.FIVE, fiveOfHearts.getRank());
		assertEquals(Rank.KING, kingOfDiamonds.getRank());
		assertEquals(Rank.JACK, jackOfSpades.getRank());
	}
	
	@Test
	public void testCompareTo() {
		assertTrue(jackOfSpades.compareTo(kingOfDiamonds) > 0);
		assertTrue(sixOfClubs.compareTo(kingOfDiamonds) < 0);
		assertTrue(sixOfHearts.compareTo(fiveOfHearts) > 0);
		assertTrue(sixOfHearts.compareTo(sixOfClubs) > 0);
	}
	
	@Test
	public void testSortCards() {
		Arrays.sort(deck);
		for(int i=0; i<deck.length-1; i++){
			assertTrue(deck[i].compareTo(deck[i+1]) < 0);
		}
	}
	
}
