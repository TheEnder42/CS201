package edu.ycp.cs201.dogyears;

import java.util.Scanner;

public class DogYears {
 
	public static void main(String[] args) {
		Scanner reader = new Scanner(System.in);
		int age=0;
		String name;
		
		System.out.println("What is your name?");
		name = reader.next();
		
		System.out.printf("How old are you, %s? \n", name);
		age = reader.nextInt();
		
		System.out.printf("%s, in dog years you are %d years old.", name, age*7);
		
		
	}
}
