package edu.ycp.cs201.exam02;

public enum PokemonType {
	// IMPORTANT: do not change the order of the enumeration members
	NONE,
	NORMAL,
	GRASS,
	BUG,
	POISON,
	FLYING,
	FIRE,
	WATER,
	ELECTRIC,
	FAIRY,
}
