package edu.ycp.cs201.pi;

import java.util.Scanner;

public class EstimatePi {
	private static final int NUM_POINTS = 100000000;
	
	public static void main(String[] args) throws InterruptedException {
		Scanner keyboard = new Scanner(System.in);
		
		System.out.print("How many computation threads? ");
		int numThreads = keyboard.nextInt();

		double a = 0.0; // estimated area
		
		double begin = System.currentTimeMillis();
		double piest=0;
		if (numThreads == 1) {
			// TODO: sequential computation
			PiTask task = new PiTask(NUM_POINTS);
			task.run();
			piest = task.getCount();
		} else if (numThreads == 2) {
			// TODO: parallel computation using 2 threads
			PiTask task = new PiTask(NUM_POINTS/2);
			PiTask task2 = new PiTask(NUM_POINTS/2);
			Thread t1 = new Thread(task);
			Thread t2 = new Thread(task2);
			t1.start();
			t2.start();
			t1.join();
			t2.join();
			
			piest += task.getCount() + task2.getCount();
		} else {
			throw new IllegalArgumentException("only 1 or 2 threads are allowed");
		}
		
		double end = System.currentTimeMillis();
		
		System.out.println("Computation took " + (end - begin) + " milliseconds");

		// TODO: compute estimate of pi, print it
		System.out.println("Pi = " + (piest/NUM_POINTS)/.25);
	}
}
