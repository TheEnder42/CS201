package edu.ycp.cs201.exam03;

public class Q9 {
	// IMPORTANT: you MUST use recursion to implement this method.
	// Do not use a loop.
	public static int countTall(String s) {
		int result=0;
		
		
		char c = 0;
		if(s.length()>0){
			c = s.charAt(0);
		}
		else{
			return result;
		}
		//base case 
		//case statements would be better, but i forget how to start one
		if(Character.isUpperCase(c)){
			result = 1;
		}
		else if(c=='b' || c=='d' || c=='f' || c=='h' || c=='k' || c=='l' || c=='t'){
			result = 1;
		}
		
		if(s.length()>1){
			result += countTall(s.substring(1));
		}
		else if (s.length()==1){
			result += countTall(s.substring(0));
		}

		return result;
		
	}
}
