package edu.ycp.cs201.exam03;

import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

public class Stats {
	// TODO: add fields
	Map<String, Integer> byName;
	Map<Integer, Integer> byGame;
	
	/**
	 * Constructor.
	 */
	public Stats() {
		// TODO: initialize fields
		byName = new TreeMap<String, Integer>();
		byGame = new TreeMap<Integer, Integer>();
	}
	
	/**
	 * Record the number of runs a particular player scored
	 * in a specific game.
	 * 
	 * @param player   the player
	 * @param game     the game number
	 * @param numRuns  the number of runs scored
	 */
	public void updateStats(String player, int game, int numRuns) {
		// TODO: implement
		if(!byName.containsKey(player)){
			byName.put(player, numRuns);
		}
		else{
			byName.put(player, byName.get(player)+numRuns);
		}
		
		if(!byGame.containsKey(game)){
			byGame.put(game, numRuns);
		}
		else{
			byGame.put(game, byGame.get(game)+numRuns);
		}
	}
	
	/**
	 * Get the number of runs a player scored over all games.
	 * 
	 * @param player the player
	 * @return the number of runs
	 */
	public int getRunsForPlayer(String player) {
		return byName.get(player);
	}
	
	/**
	 * Get the number of runs scored in a game (by all players).
	 * 
	 * @param game the game number
	 * @return the number of runs
	 */
	public int getRunsForGame(int game) {
		return byGame.get(game);
	}
}
