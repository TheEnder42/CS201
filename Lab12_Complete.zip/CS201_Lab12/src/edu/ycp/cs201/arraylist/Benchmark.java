package edu.ycp.cs201.arraylist;

public class Benchmark {
	public static void main(String[] args) {
		// TODO: benchmark removing all elements from an ArrayList
		// using two techniques
		//
		//   - repeatedly removing the last element
		//   - repeatedly removing the first element
		//
		// Measure the time to remove 10,000, 20,000, etc. elements,
		// up to 100,000 elements, for each technique.

		for (int size = 10000; size <= 100000; size += 10000) {

			ArrayList<Integer> a1, a2;

			a1 = create(size);
			System.gc();
			// TODO: benchmark code
			long start = System.currentTimeMillis();
			for(int i=0; i<size;i++){
				a1.remove(0);
			}
			long end = System.currentTimeMillis();
			long elapsed1 = end - start;

			a2 = create(size);
			System.gc();
			// TODO: benchmark code
			start = System.currentTimeMillis();
			for(int i=size-1; i>-1; i--){
				a2.remove(i);
			}
			end = System.currentTimeMillis();
			long elapsed2 = end - start;
			
			// TODO: print out results
			System.out.println(size + ", Forwards: " + elapsed1 + ", Backwards: " + elapsed2);
		}

	}

	public static ArrayList<Integer> create(int count) {
		ArrayList<Integer> a = new ArrayList<Integer>(count);
		for (int i = 0; i < count; i++) {
			a.add((Integer) 42);
		}
		return a;
	}
}
