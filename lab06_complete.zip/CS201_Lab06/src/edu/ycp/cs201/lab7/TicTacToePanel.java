package edu.ycp.cs201.lab7;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JPanel;

public class TicTacToePanel extends JPanel {
	private static final long serialVersionUID = 1L;

	private static final int WIDTH = 300;
	private static final int HEIGHT = 300;
	
	// TODO: add fields to store state
	private int[][] board = new int[3][3];
	
	// constructor
	public TicTacToePanel() {
		setPreferredSize(new Dimension(WIDTH, HEIGHT));
		setBackground(Color.BLACK);
		
		addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				handleMouseClick(e);
			}
		});
	}
	
	private void handleMouseClick(MouseEvent e) {
		if (e.getButton() == MouseEvent.BUTTON1) {
		    // left button
			//where is pointer?
			int x = (e.getX()/100);
			int y = (e.getY()/100);
			board[y][x] = 1;
			
		} else if (e.getButton() == MouseEvent.BUTTON3) {
		    // right button
			int x = (e.getX()/100);
			int y = (e.getY()/100);
			board[y][x] = 2;
			
		}
		repaint();
	}
	
	@Override
	public void paint(Graphics g) {
		super.paint(g); // paint background
		
		// TODO: draw the tic-tac-toe board
		g.setColor(Color.WHITE);
		g.fillRect(99, 0, 1, 300);
		g.fillRect(199, 0, 1, 300);
		g.fillRect(0, 99, 300, 1);
		g.fillRect(0, 199, 300, 1);
		
		for(int i=0; i<3; i++){
			for(int j=0; j<3; j++){
				if(board[j][i]==1){
					g.setColor(Color.GREEN);
					g.fillRect(i*100+5, j*100+5, 90, 90);
				}//end if 'X'
				else if (board[j][i]==2){
					g.setColor(Color.BLUE);
					g.fillOval(i*100+5, j*100+5, 90, 90);
				}//end if 'O'
			}//end inner loop
		}//end outer loop
	}//end paint
}//end class
