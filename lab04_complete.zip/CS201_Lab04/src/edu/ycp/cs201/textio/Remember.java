package edu.ycp.cs201.textio;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class Remember {
	private static String name = new String();
	private static Scanner sReader = new Scanner(System.in);
	public static void main(String[] args) throws IOException {
		load();
		talk();
		save();
		
	}//end main
	
	public static void load() throws IOException{
		try {
			FileReader fReader = new FileReader("src//memory.txt");
			BufferedReader bReader = new BufferedReader(fReader);
			name = bReader.readLine();
			System.out.println("The last person to run the program was " + name);
			bReader.close();
		} //end try
		
		catch (FileNotFoundException e) {
			System.out.println("No one has run this program before!");
		}//end catch

	}//end load
	
	public static void talk(){
		System.out.println("What is your name? ");
        name = sReader.next();
        System.out.printf("Ok, %s, I'm writing your name to a file", name);
	}//end talk
	
	public static void save() throws IOException{
		try{
			FileWriter writer = new FileWriter("src//memory.txt");
			writer.write(name);
			writer.close();
		}//end try
		catch (FileNotFoundException e) {
			System.out.println("Cannot write to file.");
		}//end catch
	}//end save
	
}//end class
