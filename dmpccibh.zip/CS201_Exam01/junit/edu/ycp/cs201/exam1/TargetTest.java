package edu.ycp.cs201.exam1;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class TargetTest {
	private static final double DELTA = 0.000001;	
	
	// declare 3 different size "quivers" of arrows to test with
	private Point[] arrows4;
	private Point[] arrows8;
	private Point[] arrows10;
	
	// declare Targets for each size "quiver"
	private Target target4;
	private Target target8;
	private Target target10;
	
	@Before
	public void setUp() throws Exception {
		// set up 4 quiver with 4 arrows
		arrows4    = new Point[4];
		arrows4[0] = new Point(1,0);
		arrows4[1] = new Point(0,1);
		arrows4[2] = new Point(-1,0);
		arrows4[3] = new Point(0,-1);
		
		// set up quiver with arrows
		arrows8    = new Point[8];
		arrows8[0] = new Point(1,1);
		arrows8[1] = new Point(1,-1);
		arrows8[2] = new Point(-1,1);
		arrows8[3] = new Point(-1,-1);
		arrows8[4] = new Point(1,0);
		arrows8[5] = new Point(0,1);
		arrows8[6] = new Point(-1,0);
		arrows8[7] = new Point(0,-1);
		
		// set up quiver with 10 arrows
		arrows10    = new Point[10];
		arrows10[0] = new Point(1,1);
		arrows10[1] = new Point(1,-1);
		arrows10[2] = new Point(-1,1);
		arrows10[3] = new Point(-1,-1);
		arrows10[4] = new Point(1,0);
		arrows10[5] = new Point(0,1);
		arrows10[6] = new Point(-1,0);
		arrows10[7] = new Point(0,-1);
		arrows10[8] = new Point(1,-2);
		arrows10[9] = new Point(2,-1);
		
		// create Targets with 4, 8, and 10 arrows
		target4  = new Target(arrows4);
		target8  = new Target(arrows8);
		target10 = new Target(arrows10);
	}

	// test with 4 arrows
	@Test
	public void test4Arrows() {
		assertEquals(1.00000000, target4.getScore(), DELTA); 
	}
	
	// test with 8 arrows
	@Test
	public void test8Arrows() {
		assertEquals(1.20710678, target8.getScore(), DELTA); 
	}
	
	// test with 10 arrows
	@Test
	public void test10Arrows() {
		assertEquals(1.41289902, target10.getScore(), DELTA); 
	}	
}
