package edu.ycp.cs201.inheritance;

import junit.framework.TestCase;

public class AirplaneTest extends TestCase {
	private Trip legalTrip;
	private Trip illegalTrip;
	private Airplane myPlane;
	private static final double DELTA = 0.00001;
	
	@Override
	protected void setUp() throws Exception {
		// a Trip that can be completed by Airplane
		legalTrip = new Trip(8);
		legalTrip.setHop(0, Terrain.AIRPORT);
		legalTrip.setHop(1, Terrain.ROAD);
		legalTrip.setHop(2, Terrain.WATER);
		legalTrip.setHop(3, Terrain.MARINA);
		legalTrip.setHop(4, Terrain.MOUNTAIN);
		legalTrip.setHop(5, Terrain.FIELD);
		legalTrip.setHop(6, Terrain.FOREST);
		legalTrip.setHop(7, Terrain.AIRPORT);
		
		// a Trip that cannot be completed by Airplane
		// because it contains an endpoint in WATER
		illegalTrip = new Trip(5);
		illegalTrip.setHop(0, Terrain.AIRPORT);
		illegalTrip.setHop(1, Terrain.ROAD);
		illegalTrip.setHop(2, Terrain.ROAD);
		illegalTrip.setHop(3, Terrain.WATER);   
		illegalTrip.setHop(4, Terrain.WATER);	//planes shouldn't land in water!
		
		myPlane = new Airplane(500);
	}
	
	public void testLegalTrip() throws Exception {
		assertTrue(legalTrip.isTripPossible(myPlane));
	}
	
	public void testIllegalTrip() throws Exception {
		assertFalse(illegalTrip.isTripPossible(myPlane));
	}
	
	public void testGetSpeed() {
		  // full speed through anything
		  assertEquals( 500.0, myPlane.getSpeed(Terrain.ROAD), DELTA );
	}
	
	public void testFindAverageSpeed() throws Exception {
		  double dist = (double)legalTrip.getHops().length;
		  double time = 8*(1.0 / 500.0);
		  assertEquals( dist /  time, legalTrip.findAverageSpeed(myPlane), DELTA);
	}
}
