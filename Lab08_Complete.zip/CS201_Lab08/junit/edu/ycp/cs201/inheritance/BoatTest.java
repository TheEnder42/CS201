package edu.ycp.cs201.inheritance;

import junit.framework.TestCase;

public class BoatTest extends TestCase {
	private Trip legalTrip;
	private Trip illegalTrip;
	private Boat myBoat;
	private static final double DELTA = 0.00001;
	
	@Override
	protected void setUp() throws Exception {
		// a Trip that can be completed by Boat
		legalTrip = new Trip(4);
		legalTrip.setHop(0, Terrain.MARINA);
		legalTrip.setHop(1, Terrain.WATER);
		legalTrip.setHop(2, Terrain.WATER);
		legalTrip.setHop(3, Terrain.MARINA);
		
		// a Trip that cannot be completed by Boat
		// because it contains a hop through land
		illegalTrip = new Trip(5);
		illegalTrip.setHop(0, Terrain.MARINA);
		illegalTrip.setHop(1, Terrain.ROAD);  // Not possible by Boat!
		illegalTrip.setHop(2, Terrain.ROAD);  // Not possible by Boat!
		illegalTrip.setHop(3, Terrain.WATER); 
		illegalTrip.setHop(4, Terrain.MARINA);
		
		myBoat = new Boat(50);
	}
	
	public void testLegalTrip() throws Exception {
		assertTrue(legalTrip.isTripPossible(myBoat));
	}
	
	public void testIllegalTrip() throws Exception {
		assertFalse(illegalTrip.isTripPossible(myBoat));
	}
	
	public void testGetSpeed() {
		  // full speed over water
		  assertEquals( 50.0, myBoat.getSpeed(Terrain.WATER), DELTA );

		  // one-quarter speed through a marina
		  assertEquals( 0.25 * 50.0, myBoat.getSpeed(Terrain.MARINA), DELTA );
	}
	
	public void testFindAverageSpeed() throws Exception {
		  double dist = (double)legalTrip.getHops().length;
		  double time = (1.0/(.25 * 50.0)) + (1.0 / 50.0) + (1.0 / 50.0) + (1.0 / (.25 * 50.0));
		  assertEquals( dist /  time, legalTrip.findAverageSpeed(myBoat), DELTA);
	}
}
