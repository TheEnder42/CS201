package edu.ycp.cs201.inheritance;

public class Airplane extends Vehicle {

	public Airplane(double maxSpeed) {
		super(maxSpeed);
	}

	@Override
	public boolean endTrip(Terrain t) {
		if ( t == Terrain.AIRPORT) {
			return true;
		} else {
			return false;
		}
	}

	@Override
	public boolean move(Terrain t) {
		//if ( t == Terrain.AIRPORT || t == Terrain.MARINA || t == Terrain.ROAD ) {
			return true;
		//} else {
			//return false;
		//}
	}

	@Override
	public boolean startTrip(Terrain t) {
		if ( t == Terrain.AIRPORT) {
			return true;
		} else {
			return false;
		}
	}
	
	@Override
	public double getSpeed(Terrain t){
		return super.getMaxSpeed();
	}
}
