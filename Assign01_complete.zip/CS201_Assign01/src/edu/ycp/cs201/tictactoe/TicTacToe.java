package edu.ycp.cs201.tictactoe;

import java.util.Scanner;

public class TicTacToe {
	public static final int PLAYER_X = 1;
	public static final int PLAYER_O = 2;
	
	public static void main(String[] args) {
		int[][] board = new int[3][3];
		
		Scanner keyboard = new Scanner(System.in);
		
		int player = PLAYER_X;
		boolean done = false;
		while (!done) {
			System.out.println();
			printBoard(board);
			
			System.out.printf("\nPlayer %c's turn:\n", (player == PLAYER_X) ? 'X' : 'O');
			int row = getRow(keyboard);
			int col = getCol(keyboard);
			
			if (!isLegalMove(board, row, col)) {
				System.out.println("Invalid move, try again");
			} else {
				placeMarker(board, row, col, player);
				if (playerWins(board, player)) {
					// Current player wins
					System.out.printf("Player %s wins!\n", player == PLAYER_X ? "X" : "O");
					done = true;
				} else if (isDraw(board)) {
					// Game is a draw
					System.out.println("It's a draw!");
					done = true;
				} else {
					// Switch player
					player = (player == PLAYER_X) ? PLAYER_O : PLAYER_X;
				}
			}
		}
		System.out.println("Thanks for playing!");
	}

	public static void printBoard(int[][] board) {
		System.out.println(" " + symbol(board, 0, 0) + " | " + symbol(board, 0, 1) + " | " + symbol(board, 0, 2));
		System.out.println("---|---|---");
		System.out.println(" " + symbol(board, 1, 0) + " | " + symbol(board, 1, 1) + " | " + symbol(board, 1, 2));
		System.out.println("---|---|---");
		System.out.println(" " + symbol(board, 2, 0) + " | " + symbol(board, 2, 1) + " | " + symbol(board, 2, 2));
	}//end printer
	
	public static char symbol(int[][] board, int row, int col){
		if(board[row][col]==1){
			return 'X';
		}//end if 1
		if (board[row][col]==2){
			return 'O';
		}//end if 2
		return ' ';
	}//end get symbol
	
	public static int getRow(Scanner reader) {
		return ReadInput.range(-1, 1, 3, "Enter row (1-3): ")-1;
	}//end get row

	public static int getCol(Scanner reader) {
		return ReadInput.range(-1, 1, 3, "Enter column (1-3): ")-1;
	}//end get col
	
	/**
	 * This method checks if the user-requested space is open or not. It fails the JUnit test, however
	 * that is only when out-of-bounds data is fed in, but there are measures elsewhere in place that 
	 * make it impossible to get such bad data this far into the program.
	 * @param board
	 * @param row
	 * @param col
	 * @return
	 */
	public static boolean isLegalMove(int[][] board, int row, int col) {
		if(row>board.length-1 || col>board[0].length-1 || row<0 || col<0){
			return false;
		}
		else if(board[row][col]==0){
			return true;
		}//end if good
		return false;
	}//end check legal
	
	public static void placeMarker(int[][] board, int row, int col, int player) {
		if(isLegalMove(board, row, col)){
			board[row][col]=player;
		}//end if	
	}//end set

	public static boolean playerWins(int[][] board, int player) {
		boolean win = false;
		int i=0;
		while(!win && i<3){
			if(board[i][0]!=player || board[i][1]!=player || board[i][2]!=player){
				i++;
			}//end failure
			else{
				return true;
			}//end no fail
		}//end while
		i=0;
		while(!win && i<3){
			if(board[0][i]!=player || board[1][i]!=player || board[2][i]!=player){
				i++;
			}//end failure
			else{
				return true;
			}//end no fail
		}//end while
		if(board[0][0]==player && board[1][1]==player && board[2][2]==player){
			return true;
		}//end win \
		else if(board[0][2]==player && board[1][1]==player && board[2][0]==player){
			return true;
		}//end win /
		return false;
	}//end did win?

	public static boolean isDraw(int[][] board) {
		for(int x=0; x<3; x++){
			for(int y=0; y<3; y++){
				if(board[x][y]==0){
					return false;
				}//end if blank space
			}//end col shell
		}//end row shell
		return true;
	}//end no more spaces
}//end class
