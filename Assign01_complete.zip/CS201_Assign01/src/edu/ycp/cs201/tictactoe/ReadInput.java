package edu.ycp.cs201.tictactoe;
//Matt Ritchie
//CS201
//Tic Tac Toe				projname
//9-12-16					dropdate

import java.util.Scanner;

/**
 * @author Matt Ritchie
 * @see TicTacToe
 */
public class ReadInput {
	/**Instantiates a scanner to read the user's inputs.*/
	private static Scanner reader = new Scanner(System.in);
	
	/**
	 * Gets passed instructions to print for the user, as well as the limits of the acceptable range of user inputs and loops until the user enters a valid int.
	 * @param seed
	 * @param start
	 * @param end
	 * @param info
	 * @return
	 */
	public static int range(int seed, int start, int end, String info){
		while (seed>end || seed<start){
			System.out.println(info);
			if (reader.hasNextInt()){
				seed = reader.nextInt();
				if (!(seed>=start && seed<=end)){
					System.out.println("That is not a number within the valid range.");
					reader.nextLine();
					seed=-1;
				}//end range error
			}//end ifGood
			else {
				System.out.println("That is not a valid entry.");
				reader.nextLine();
			}//end input error 
		}//end while
		return seed;
	}//end range
	
	/**
	 * Gets passed instructions to print for the user, as well as the limits of the acceptable range of user inputs and loops until the user enters a valid double.
	 * @param seed
	 * @param start
	 * @param end
	 * @param info
	 * @return
	 */
	public static double range(double seed, double start, double end, String info){
		while (seed>end || seed<start){
			System.out.println(info);
			if (reader.hasNextDouble()){
				seed = reader.nextDouble();
				if (!(seed>=start && seed<=end)){
					System.out.println("That is not a number within the valid range.");
					reader.nextLine();
					seed=-1;
				}//end range error
			}//end ifGood
			else {
				System.out.println("That is not a valid entry.");
				reader.nextLine();
			}//end input error 
		}//end while
		return seed;
	}//end range
	
	/**
	 * Gets passed instructions to print for the user and loops until the user enters a positive double.
	 * @param seed
	 * @param info
	 * @return
	 */
	public static double positive(double seed, String info){
		while (seed<0){
			System.out.println(info);
			if (reader.hasNextDouble()){
				seed = reader.nextDouble();
				if (!(seed>0)){
					System.out.println("That is not a valid number.");
					reader.nextLine();
					seed=-1;
				}//end range error
			}//end ifGood
			else {
				System.out.println("That is not a valid entry.");
				reader.nextLine();
			}//end input error 
		}//end while
		return seed;
	}//end range
	
	/**
	 * Gets passed instructions to print for the user and loops until the user enters a positive int.
	 * @param seed
	 * @param info
	 * @return
	 */
	public static int positive(int seed, String info){
		while (seed<0){
			System.out.println(info);
			if (reader.hasNextInt()){
				seed = reader.nextInt();
				if (!(seed>0)){
					System.out.println("That is not a valid number.");
					reader.nextLine();
					seed=-1;
				}//end range error
			}//end ifGood
			else {
				System.out.println("That is not a valid entry.");
				reader.nextLine();
			}//end input error 
		}//end while
		return seed;
	}//end range
	
	/**
	 * Gets passed instructions to print for the user and loops until the user enters a letter A-D. Case doesn't matter. Useful for multiple choice questions to the user.
	 * @param seed
	 * @param info
	 * @return
	 */
	public static char aThruD(char seed, String info){
		String test;
		while(seed!='A' && seed!='B' && seed!='C' && seed!='D'){
			System.out.println(info);
			test = reader.nextLine();
			seed = Character.toUpperCase(test.charAt(0));
			if (seed!='A' && seed!='B' && seed!='C' && seed!='D'){
				System.out.println("That is not a valid entry.");
			}//end check
		}//end loop
		return seed;
	}//end char range
	
}//end class
