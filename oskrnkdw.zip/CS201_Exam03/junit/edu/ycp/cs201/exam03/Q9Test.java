package edu.ycp.cs201.exam03;

import static org.junit.Assert.*;

import org.junit.Test;

public class Q9Test {
	@Test
	public void testCountTall1() throws Exception {
		assertEquals(5, Q9.countTall("Hello, world!"));
	}
	
	@Test
	public void testCountTall2() throws Exception {
		assertEquals(7, Q9.countTall("abcdefghijklmnopqrstuvwxyz"));
	}
	
	@Test
	public void testCountTall3() throws Exception {
		assertEquals(0, Q9.countTall(""));
	}
	
	@Test
	public void testCountTall4() throws Exception {
		assertEquals(10, Q9.countTall("O Michigan, exemplar of unchecked replication"));
	}
	
	@Test
	public void testCountTall5() throws Exception {
		assertEquals(10, Q9.countTall("Iä! Iä! Cthulhu fhtagn!"));
	}
	
	@Test
	public void testCountTall6() throws Exception {
		assertEquals(11, Q9.countTall("and now for something completely different"));
	}
}
