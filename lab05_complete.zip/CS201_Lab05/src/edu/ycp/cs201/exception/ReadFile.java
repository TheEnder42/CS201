package edu.ycp.cs201.exception;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class ReadFile {
	//
	// Requirements:
	// - do not add "throws IOException" (or any other throws clause)
	//   to the main() method
	// - do not test whether or not the requested file exists
	//   before trying to open it
	// - use a try/finally block to make sure that the
	//   file reader or input stream is closed
	//
	public static void main(String[] args) {
		Scanner reader = new Scanner(System.in);
		// Prompt the user to enter a filename
		System.out.println("Enter file name: ");
		// Print the contents of the file to System.out
		try{
			String fileName = reader.next();
			printFile(fileName);
		}//end try
		catch(IOException e){
			System.out.println("Error: " + e.getMessage());
		}//end catch
			
		reader.close();

		// If the file can't be opened, or if an
		// IOException occurs, print an error message
	}//end main

	private static void printFile(String fileName)
			throws FileNotFoundException, IOException {
		FileReader fReader = new FileReader(fileName);
		BufferedReader bReader = new BufferedReader(fReader);
		try{
			while (true) {
				String line = bReader.readLine();
				if (line == null) {
					break;
				}//end if
				System.out.println(line);
			}//end while
		}//end try
		finally{
			bReader.close();
		}//end finally
		
	}
}
