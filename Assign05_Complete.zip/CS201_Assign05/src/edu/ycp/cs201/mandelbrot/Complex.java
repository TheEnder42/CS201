package edu.ycp.cs201.mandelbrot;

public class Complex {
	private double real, imag;
	
	public Complex(double r, double i){
		real = r;
		imag = i;
	}//end constructor
	
	public Complex add(Complex other) {
		Complex result = new Complex(0,0);
		result.setReal(real+other.getReal());
		result.setImag(imag+other.getImag());
		return result;
    }

    // multiply given complex number by this one, returning the Complex result
    public Complex multiply(Complex other) {
    	Complex result = new Complex(0,0);
    	result.setReal(real*other.getReal() - imag*other.getImag());
		result.setImag(imag*other.getReal() + real*other.getImag());    	
    	return result;
    }

    // get the magnitude of this complex number
    public double getMagnitude() {
    	double mag = Math.sqrt(real*real + imag*imag);
       return mag;
    }

	/**
	 * @return the real
	 */
	public double getReal() {
		return real;
	}

	/**
	 * @param real the real to set
	 */
	public void setReal(double real) {
		this.real = real;
	}

	/**
	 * @return the imag
	 */
	public double getImag() {
		return imag;
	}

	/**
	 * @param imag the imag to set
	 */
	public void setImag(double imag) {
		this.imag = imag;
	}
	
    
	
}//end class
