package edu.ycp.cs201.mandelbrot;

public class MandelbrotTask implements Runnable {
    private double x1, y1, x2, y2;
    private int startCol, endCol, startRow, endRow;
    private int[][] iterCounts;

    public MandelbrotTask(double x1, double y1, double x2, double y2,
                          int startCol, int endCol, int startRow, int endRow,
                          int[][] iterCounts) {
        this.x1 = x1;
        this.y1 = y1;
        this.x2 = x2;
        this.y2 = y2;
        this.startCol = startCol;
        this.endCol = endCol;
        this.startRow = startRow;
        this.endRow = endRow;
        this.iterCounts = iterCounts;
    }

    public void run() {
        for (int i = startRow; i < endRow; i++) {
            for (int j = startCol; j < endCol; j++) {
                Complex c = getComplex(i, j);
                int iterCount = computeIterCount(c);
                iterCounts[i][j] = iterCount;
            }
        }
    }

    // TODO: implement getComplex and computeIterCount methods
    public Complex getComplex(int i, int j){
    	Complex result = new Complex(0,0);
    	result.setReal(x1 + (j*((x2-x1)/600)));
		result.setImag(y1 + (i*((y2-y1)/600)));    	
    	return result;
    }//end get complex at x/y pixel
    
    public int computeIterCount(Complex c){
    	int iters=0;
    	Complex result = new Complex(0,0);
    	while(result.getMagnitude()<2 && iters<1000){
    		//not sure if this is ok
    		result = result.multiply(result).add(c);
    		iters++;
    	}
    	System.out.println(iters);
    	return iters;
    }

	/**
	 * @return the iterCounts
	 */
	public int[][] getIterCounts() {
		return iterCounts;
	}
    
    
    
}//end class