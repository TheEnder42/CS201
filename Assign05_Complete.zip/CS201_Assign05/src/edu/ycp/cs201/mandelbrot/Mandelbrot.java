package edu.ycp.cs201.mandelbrot;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.BufferedOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Scanner;

import javax.imageio.ImageIO;

public class Mandelbrot {
	public static final int HEIGHT = 600;

	public static final int WIDTH = 600;

	public static void main(String[] args) throws IOException {
		Scanner keyboard = new Scanner(System.in);
		
		System.out.println("Please enter coordinates of region to render:");
		System.out.print("  x1: ");
		double x1 = keyboard.nextDouble();
		System.out.print("  y1: ");
		double y1 = keyboard.nextDouble();
		System.out.print("  x2: ");
		double x2 = keyboard.nextDouble();
		System.out.print("  y2: ");
		double y2 = keyboard.nextDouble();

		System.out.print("Output filename: ");
		String fileName = keyboard.next();
		
		// TODO: create the rendering, save it to a file
		//System.out.print("Calculating....");
		
		int[][] iterCounts = new int[HEIGHT][WIDTH];
		//thread separation acquired from Hake
		MandelbrotTask task1 = new MandelbrotTask(x1, y1, x2, y1+(y2-y1)/4, 0, 150, 0, HEIGHT, iterCounts);
		MandelbrotTask task2 = new MandelbrotTask(x1, y1, x2, y1+(y2-y1)/2, 0, 300, 0, HEIGHT, iterCounts);
		MandelbrotTask task3 = new MandelbrotTask(x1, y1, x2, y1+(y2-y1)*3/4, 0, 450, 0, HEIGHT, iterCounts);
		MandelbrotTask task4 = new MandelbrotTask(x1, y1, x2, y1+(y2-y1), 0, 600, 0, HEIGHT, iterCounts);
		task1.run();
		task2.run();
		task3.run();
		task4.run();
		//System.out.println("Done.");
		
		BufferedImage bufferedImage = new BufferedImage(WIDTH, HEIGHT, BufferedImage.TYPE_INT_ARGB);
		Graphics g = bufferedImage.getGraphics();
		//System.out.println("G made.");
		// ... use g to perform drawing operations ...
		//System.out.print("Drawing...");
		for(int i=0; i<HEIGHT; i++){
			for(int k=0; k<WIDTH; k++){
				if(iterCounts[i][k]==1000){
					g.setColor(Color.BLACK);
				}
				else if(iterCounts[i][k]>800){
					g.setColor(Color.RED);
				}
				else if(iterCounts[i][k]>500){
					g.setColor(Color.YELLOW);
				}
				else{
					g.setColor(Color.BLUE);
				}
				g.drawRect(k, i, 1, 1);
			}//end one row
		}//end all rows
		//System.out.println("Complete.");
		OutputStream os = new BufferedOutputStream(new FileOutputStream(fileName));
		try {
		    ImageIO.write(bufferedImage, "PNG", os);
		    System.out.println("Saved.");
		} finally {
		    os.close();
		    //System.out.println("Cleaned");
		}
		//System.out.println("Done.");
		g.dispose();
	}
}
